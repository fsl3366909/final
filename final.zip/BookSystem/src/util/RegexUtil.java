/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * regex
 * @author follow
 */
public class RegexUtil {
    
    private final static String PWD = "^[A-Z].{5,}$";
    
    private RegexUtil(){
        
    }
    
    /**
     *
     * @param regex
     * @param str
     * @return
     */
    private static boolean checkStr(String regex, String str){
        if(regex == null || str == null){
            return false;
        }
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(str);
        return m.matches();
    }
    
    /**
     * checkPwd
     * @param str
     * @return 
     */
    public static boolean checkPwd(String str){
        return checkStr(PWD, str);
    }
 
}
