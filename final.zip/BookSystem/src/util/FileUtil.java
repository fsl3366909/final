/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;

/**
 *
 * @author follow
 */
public class FileUtil {
    
    private final static String UPLOAD_PATH = "D:/work/file/";
    
    private static final char[] CHAR_ARR = ("0123456789abcdefghijklmnopqrstuvwxyz"
			+ "ABCDEFGHIJKLMNOPQRSTUVWXYZ").toCharArray();
    
    private FileUtil(){
        
    }
   
    /**
     * upload img
     * @param file
     * @param filename
     * @throws IOException 
     */
    public static void upload(File file, String filename) throws IOException{
        File newPath = new File(UPLOAD_PATH);
        if(!newPath.exists()){
            newPath.mkdirs();
        }   
        file.renameTo(new File(UPLOAD_PATH + filename));
    }
    
    /**
     * get img
     * @param filename
     * @return
     * @throws IOException 
     */
    public static Image getImg(String filename) throws IOException{
        return ImageIO.read(new File(UPLOAD_PATH + filename));
    }
    
    /**
     * get verify img
     * @param code
     * @param width
     * @param height
     * @param size
     * @return 
     */
    public static BufferedImage getVerifyImg(String code, int width, int height, int size){
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);	
	Graphics graphic = image.getGraphics();
	graphic.setColor(Color.LIGHT_GRAY);
	graphic.fillRect(0, 0, width, height);
        for (int i = 0; i <code.length(); i++) {
            graphic.setColor(getRandomColor());
            graphic.setFont(new Font(
                    null, Font.BOLD + Font.ITALIC, size));
            graphic.drawString(
                    code.charAt(i) + "", (i + 1) * width / 6, height - 10);
        }
        for (int i = 0; i < 3; i++) {
            Random ran = new Random();
            // 设置随机颜色
            graphic.setColor(getRandomColor());
            // 随机画线
            graphic.drawLine(ran.nextInt(width), ran.nextInt(height),ran.nextInt(width), ran.nextInt(height));
        }
        return image;
    }
    
    /**
     * get random color
     * @return 
     */
    public static Color getRandomColor() {
        Random ran = new Random();
        Color color = new Color(ran.nextInt(256), ran.nextInt(256), ran.nextInt(256));
        return color;
    }
    
    /**
     * 获取length
     * @param length
     * @return 
     */
    public static String getRandomCode(int length){
        Random ran = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int n = ran.nextInt(CHAR_ARR.length);
            sb.append(CHAR_ARR[n]);
        }
        return sb.toString();
    }
}
