package dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.User;
import dao.base.BaseDaoImpl;
import dao.UserDao;

/**
 * CRUD(create, read, update, delete)
 * @author wind
 *
 */
public class UserDaoImpl extends BaseDaoImpl<User, Integer> implements UserDao{

    
    
    /**
     *
     * @param user
     * @return
     */
    @Override
    public int insert(User user) {
        String sql = "insert into user values(?, ?, ?, ?)";
        return super.executeUpdate(sql, ps -> {
            ps.setString(1, null);
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setInt(4, user.getType());
        });
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public int deleteById(Integer id) {
        String sql = "delete from user where id = ?";
        return super.executeUpdate(sql, ps -> ps.setInt(1, id));
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public User findById(Integer id) {
        String sql = "select * from user where id = ?";
        List<User> users = super.executeQuery(sql, ps -> ps.setInt(1, id));
        if(users.size() == 1){
            return users.get(0);
        }
        return null;
    }


    /**
     * 
     * @return
     */
    @Override
    public List<User> findByCondition(User user) {
        String sql = "select * from user where 1=1";
        String whereClause = "";

        String username = user.getUsername();
        if(username != null){
            whereClause += " and username like '%" + username + "%' ";
        }
        
        String typeStr = user.getTypeStr();
        if(typeStr != null){
            whereClause += " and type in (" + typeStr + ")";
        }

        sql += whereClause;
        //System.out.println(sql);
        return super.executeQuery(sql, ps -> {
            
        });
    }

    /**
     * 
     * @return
     */
    @Override
    public int updateConditionById(User user) {
        String sql = "update user ";
        String setSql = "set ";

        String password = user.getPassword();
        if(password != null){
            setSql += ("password = '" + password + "', ");
        }


        Integer id = user.getId();
        if(id != null && setSql.contains(",")){
            sql += setSql.substring(0, setSql.length() - 2);
            sql += " where id = ?";

            return super.executeUpdate(sql, ps -> ps.setInt(1, id));
        }
        return -1;
    }


    @Override
    public User parseTable(ResultSet rs) throws SQLException {
        User user = new User();
        user.setId(rs.getInt("id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setType(rs.getInt("type"));
        return user;
    }

    @Override
    public User login(String username, String password) {
        String sql = "select * from user where username = ? and password = ?";
        List<User> list =  super.executeQuery(sql, ps -> {
            ps.setString(1, username);
            ps.setString(2, password);
        });
        if(!list.isEmpty()){
            return list.get(0);
        }
        return null;
    }

    @Override
    public User findByName(String username) {
        String sql = "select * from user where username = ?";
        List<User> list =  super.executeQuery(sql, ps -> {
            ps.setString(1, username);
        });
        if(!list.isEmpty()){
            return list.get(0);
        }
        return null;
    }
}
