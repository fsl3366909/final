package dao.impl;

import dao.MaterialDao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import dao.base.BaseDaoImpl;
import model.Material;

/**
 * CRUD(create, read, update, delete)
 * @author wind
 *
 */
public class MaterialDaoImpl extends BaseDaoImpl<Material, Integer> implements MaterialDao{

    
    
    /**
     *
     * @param material
     * @return
     */
    @Override
    public int insert(Material material) {
        String sql = "insert into material values(?, ?, ?, ?, ?)";
        return super.executeUpdate(sql, ps -> {
            ps.setString(1, null);
            ps.setString(2, material.getName());
            ps.setString(3, material.getImg());
            ps.setFloat(4, material.getPrice());
            ps.setInt(5, material.getUserId());
        });
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public int deleteById(Integer id) {
        String sql = "delete from material where id = ?";
        return super.executeUpdate(sql, ps -> ps.setInt(1, id));
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public Material findById(Integer id) {
        String sql = "select * from material where id = ?";
        List<Material> list = super.executeQuery(sql, ps -> ps.setInt(1, id));
        if(list.size() == 1){
            return list.get(0);
        }
        return null;
    }


    /**
     * 
     * @return
     */
    @Override
    public List<Material> findByCondition(Material material) {
        String sql = "select m.*,u.username from material m left join user u on m.user_id = u.id where 1=1";
        String whereClause = "";

        String name = material.getName();
        if(name != null){
            whereClause += "and m.name = " + name + " ";
        }

        sql += whereClause;
        return super.executeQuery(sql, ps -> {
            
        });
    }

    /**
     * 
     * @return
     */
    @Override
    public int updateConditionById(Material material) {
        String sql = "update material ";
        String setSql = "set ";

        String name = material.getName();
        if(name != null){
            setSql += ("name = '" + name + "', ");
        }
        Float price = material.getPrice();
        if(price != null){
            setSql += ("price = '" + price + "', ");
        }

        Integer id = material.getId();
        if(id != null && setSql.contains(",")){
            sql += setSql.substring(0, setSql.length() - 2);
            sql += " where id = ?";

            return super.executeUpdate(sql, ps -> ps.setInt(1, id));
        }
        return -1;
    }


    @Override
    public Material parseTable(ResultSet rs) throws SQLException {
        Material material = new Material();
        material.setId(rs.getInt("id"));
        material.setName(rs.getString("name"));
        try{
            material.setUsername(rs.getString("username"));
        }catch(Exception e){
            
        }
        material.setImg(rs.getString("img"));
        material.setPrice(rs.getFloat("price"));
        material.setUserId(rs.getInt("user_id"));
        return material;
    }
}
