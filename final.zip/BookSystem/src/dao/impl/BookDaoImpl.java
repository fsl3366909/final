package dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.Book;
import dao.base.BaseDaoImpl;
import dao.BookDao;

/**
 * CRUD(create, read, update, delete)
 * @author wind
 *
 */
public class BookDaoImpl extends BaseDaoImpl<Book, Integer> implements BookDao {

    /**
     * 添加图书
     * @param book
     * @return
     */
    @Override
    public int insert(Book book){
        String sql = "insert into book values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        return super.executeUpdate(sql, ps -> {
            ps.setString(1, null);
            ps.setString(2, book.getName());
            ps.setString(3, book.getAuthor());
            ps.setString(4, book.getPublisher());
            ps.setString(5, book.getImg());
            ps.setString(6, book.getStatus());
            ps.setInt(7, book.getUserId());
            ps.setString(8, book.getPublicationDate());
            ps.setInt(9, book.getType());
        });
    }

    /**
     * 删除图书通过图书id
     * @param id
     * @return
     */
    @Override
    public int deleteById(Integer id){
        String sql = "delete from book where id = ?";
        return super.executeUpdate(sql, ps -> ps.setInt(1, id));
    }


    /**
     * 查找图书通过id
     * @param id
     * @return
     */
    @Override
    public Book findById(Integer id){
        String sql = "select * from book where id = ?";
        List<Book> books = super.executeQuery(sql, ps -> ps.setInt(1, id));
        if(books.size() == 1){
            return books.get(0);
        }
        return null;
    }

    /**
     * 根据条件查询
     * @param book
     * @return
     */
    @Override
    public List<Book> findByCondition(Book book) {
        String sql = "select b.*, u.username from book b left join user u on b.user_id = u.id where 1 = 1 ";
        String whereClause = "";

        String status = book.getStatus();
        if(status != null){
            whereClause += "and b.status = " + status + " ";
        }
        
        Integer userId = book.getUserId();
        if(userId != null){
            whereClause += "and b.user_id = " + userId + " ";
        }
        
        Integer type = book.getType();
        if(type != null){
            whereClause += "and b.type = " + type + " ";
        }

        String bookName = book.getName();
        if(bookName != null){
            whereClause += "and b.name like '%" + bookName + "%' ";
        }

        sql += whereClause;
        //System.out.println(sql);
        return super.executeQuery(sql, ps -> {});
    }


    /**
     *
     * @param book
     * @return
     */
    @Override
    public int updateConditionById(Book book) {
        String sql = "update book ";
        String setSql = "set ";

        String author = book.getAuthor();
        if(author != null){
            setSql += ("author = '" + author + "', ");
        }

        String bookName = book.getName();
        if(bookName != null){
            setSql += ("name = '" + bookName + "', ");
        }

        String publishers = book.getPublisher();
        if(publishers != null){
            setSql += ("publisher = '" + publishers + "', ");
        }

        String img = book.getImg();
        if(img != null){
            setSql += ("img = '" + img + "', ");
        }
     
        String status = book.getStatus();
        if(status != null){
            setSql += ("status = '" + status + "', ");
        }

        Integer bookId = book.getId();
        if(bookId != null && setSql.contains(",")){
            sql += setSql.substring(0, setSql.length() - 2);
            sql += " where id = ?";

            return super.executeUpdate(sql, ps -> ps.setInt(1, bookId));
        }

        return -1;
    }

    @Override
    public Book parseTable(ResultSet rs) throws SQLException {
        Book book = new Book();
        book.setId(rs.getInt("id"));
        book.setName(rs.getString("name"));
        book.setPublisher(rs.getString("publisher"));
        book.setAuthor(rs.getString("author"));
        book.setStatus(rs.getString("status"));
        book.setImg(rs.getString("img"));
        book.setUserId(rs.getInt("user_id"));
        try{
            book.setUsername(rs.getString("username"));
        }catch(Exception e){
            
        }
        book.setType(rs.getInt("type"));
        book.setPublicationDate(rs.getString("publication_date"));
        return book;
    }
}
