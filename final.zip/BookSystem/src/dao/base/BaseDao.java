/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.base;

import java.util.List;

/**
 * 数据库dao通用接口
 * @author wind
 * @param <R>
 * @param <PK>
 */
public interface BaseDao<R, PK> {
    /**
     * 添加纪录
     * @param r
     * @return
     */
    int insert(R r);

    /**
     * 通过id删除记录
     * @param id
     * @return
     */
    int deleteById(PK id);

    /**
     * 通过id查询
     * @param id
     * @return
     */
    R findById(PK id);

    /**
     * 通过条件查找
     * @param r
     * @return
     */
    List<R> findByCondition(R r);

    /**
     *  通过id更新记录
     * @param r
     * @return
     */
    int updateConditionById(R r);
}
