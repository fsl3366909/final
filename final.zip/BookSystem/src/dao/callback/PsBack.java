package dao.callback;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * update call
 * @author wind
 */
@FunctionalInterface
public interface PsBack {

    /**
     * call back
     * @param ps
     * @throws SQLException
     */
    void call(PreparedStatement ps) throws SQLException;
}
