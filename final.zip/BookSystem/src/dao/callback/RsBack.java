package dao.callback;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * query callback
 * @author wind
 */
@FunctionalInterface
public interface RsBack {

    /**
     * call method
     * @param rs
     * @throws SQLException
     */
    void call(ResultSet rs) throws SQLException;
}
