/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.base.BaseDao;
import model.Book;
import model.Record;

/**
 *
 * @author follow
 */
public interface RecordDao extends BaseDao<Record, Integer> {
}
