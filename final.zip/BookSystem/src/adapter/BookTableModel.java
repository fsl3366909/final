package adapter;

import enums.StatusType;
import model.Book;

import java.util.List;

import javax.swing.table.AbstractTableModel;

/**
 * @package adapter
 * @className BookTableModel
 * @note TODO
 * @author wind
 */
public class BookTableModel extends AbstractTableModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Book> entityList;
        private String[] columns = { "id", "username", "name", "author", "publisher", "status", "date"};
        private String[] columns2 = { "id", "username", "name", "author", "publisher", "date"};
        private boolean isLib;
	public BookTableModel(List<Book> entityList, boolean isLib) {
		super();
		this.entityList = entityList;
                this.isLib = isLib;
	}

	@Override
	public int getRowCount() {
		return entityList.size();
	}

	@Override
	public int getColumnCount() {
            return isLib ? columns.length : columns2.length;
	}
	
	@Override
	public String getColumnName(int column) {
		return isLib ? columns[column] : columns2[column];
	}
	
	private Object getColumn(Book entity, int n) {
            if(isLib){
                switch (n) {
                    case 0: return entity.getId();
                    case 1: return entity.getUsername();
                    case 2: return entity.getName();
                    case 3: return entity.getAuthor();
                    case 4: return entity.getPublisher();
                    case 5: return StatusType.getName(entity.getStatus());
                    case 6: return entity.getPublicationDate();
                    default: return null;
                }
            }else{
                switch (n) {
                    case 0: return entity.getId();
                    case 1: return entity.getUsername();
                    case 2: return entity.getName();
                    case 3: return entity.getAuthor();
                    case 4: return entity.getPublisher();
                    case 5: return entity.getPublicationDate();
                    default: return null;
                }
            }
        }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return getColumn(entityList.get(rowIndex), columnIndex);
	}

}
