package adapter;


import java.util.List;

import javax.swing.table.AbstractTableModel;
import model.Material;

/**
 * @package adapter
 * @className MaterialTableModel
 * @note TODO
 * @author wind
 */
public class MaterialTableModel extends AbstractTableModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Material> entityList;
        private String[] columns = { "name", "username", "img", "price"};
    
	public MaterialTableModel(List<Material> entityList) {
		super();
		this.entityList = entityList;
	}

	@Override
	public int getRowCount() {
		return entityList.size();
	}

	@Override
	public int getColumnCount() {
		return columns.length;
	}
	
	@Override
	public String getColumnName(int column) {
		return columns[column];
	}
	
	private Object getColumn(Material entity, int n) {
        switch (n) {
            case 0: return entity.getName();
            case 1: return entity.getUsername();
            case 2: return entity.getImg();
            case 3: return entity.getPrice();
            default: return null;
        }
    }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return getColumn(entityList.get(rowIndex), columnIndex);
	}

}
