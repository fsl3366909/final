package adapter;

import enums.StatusType;
import java.text.SimpleDateFormat;
import model.Book;

import java.util.List;

import javax.swing.table.AbstractTableModel;
import model.LibOrder;
import model.ProviderOrder;

/**
 * @package adapter
 * @className OrderTableModel
 * @note TODO
 * @author wind
 */
public class ProviderOrderTableModel extends AbstractTableModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<ProviderOrder> entityList;
        private String[] columns = { "materialName", "count", "request_time", "resolve_time", "order_name"};
    
	public ProviderOrderTableModel(List<ProviderOrder> entityList) {
		super();
		this.entityList = entityList;
	}

	@Override
	public int getRowCount() {
		return entityList.size();
	}

	@Override
	public int getColumnCount() {
		return columns.length;
	}
	
	@Override
	public String getColumnName(int column) {
		return columns[column];
	}
	
	private Object getColumn(ProviderOrder entity, int n) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            switch (n) {
                case 0: return entity.getMaterialName();
                case 1: return entity.getCount();
                case 2: return format.format(entity.getRequestTime());
                case 3: return entity.getResolveTime() != null ? format.format(entity.getResolveTime()) : "";
                case 4: return entity.getUsername();
                default: return null;
            }
        }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return getColumn(entityList.get(rowIndex), columnIndex);
	}

}
