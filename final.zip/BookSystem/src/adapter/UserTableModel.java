package adapter;


import enums.UserType;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.User;
import ui.MainJFrame;

/**
 * @package adapter
 * @className BookTableModel
 * @note TODO
 * @author wind
 */
public class UserTableModel extends AbstractTableModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<User> entityList;
        private String[] columns = { "id", "username", "password", "type"};
    
	public UserTableModel(List<User> entityList) {
		super();
		this.entityList = entityList;
	}

	@Override
	public int getRowCount() {
		return entityList.size();
	}

	@Override
	public int getColumnCount() {
		return columns.length;
	}
	
	@Override
	public String getColumnName(int column) {
		return columns[column];
	}
	
	private Object getColumn(User entity, int n) {  
            switch (n) {
                case 0: return entity.getId();
                case 1: return entity.getUsername();
                case 2: return MainJFrame.loginUser != null && UserType.SYSADMIN.equalCode(MainJFrame.loginUser.getType() + "") ? entity.getPassword() : "***";
                case 3: return UserType.getName(entity.getType() + "");
                default: return null;
            }
        }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return getColumn(entityList.get(rowIndex), columnIndex);
	}

}
